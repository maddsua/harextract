## Web Archive (.har) Extractor

### Version 1.1

This thing does exactly what you think of it. 

It extracts files from `.har` as any ordinary archiver would extract from any ordinary archive.

### Change log

**v1.1**

- Unicode support added

**v1.0**

- Base version
